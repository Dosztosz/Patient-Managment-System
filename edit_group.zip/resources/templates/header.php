<!-- Top Header layout -->
<header class="bg-primary p-2 d-flex justify-content-between align-items-center">
    <h2>Control Panel</h2>
</header>