<!-- Displaying footer data -->
<footer>
    <p>Felgdent-test</p>
    <p>Created by: Tomasz Dębosz</p>
</footer>

<script>
function ShowForm(){
    $( "#form_add" ).toggle( "show" );
    $( "#form_show" ).toggle( "hide" );
    $( "#form_hide" ).toggle( "show" );
}

function Hide(){
      $( "#toggle" ).toggle( "hide" );
    }

</script>