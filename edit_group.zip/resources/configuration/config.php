<?php
//Mysql configuration file
$db_host = "127.0.0.1";
$db_user = "root";
$db_pass = "";
$db_name = "patient_managment";

?>