Hello,

Thank you for checking up my aplication.

To run the aplication you have to import a database that is named: patient_managment.sql

Please set up the config.php file that is located in resources/configuration.

Have fun checking my APP